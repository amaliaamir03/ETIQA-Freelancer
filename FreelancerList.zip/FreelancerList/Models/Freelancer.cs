﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;

namespace FreelancerList.Models
{
    public class Freelancer
    {
        public int Id { get; set; }
        [Required]
        public string Username { get; set; }
        [Required]
        public string Email { get; set; }
        [Required]
        public string PhoneNum { get; set; }
        [Required]
        public string Skills { get; set; }
        public string Hobby { get; set; }

    }
}
