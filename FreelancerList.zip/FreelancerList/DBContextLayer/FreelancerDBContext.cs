﻿using Microsoft.EntityFrameworkCore;
using FreelancerList.Models;

namespace FreelancerList.DBContext
{
    public class FreelancerDBContext: DbContext
    {
        public FreelancerDBContext(DbContextOptions options) : base(options)
        { 
        }

        public DbSet<Freelancer> FreelancerList { get; set; }
    }
}
