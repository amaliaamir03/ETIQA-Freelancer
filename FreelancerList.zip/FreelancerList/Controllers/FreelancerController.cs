﻿using FreelancerList.DBContext;
using FreelancerList.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Metadata.Conventions;
using Microsoft.Identity.Client;

namespace FreelancerList.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class FreelancerController : ControllerBase
    {
        private readonly FreelancerDBContext _context;
        public FreelancerController(FreelancerDBContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                var flist = _context.FreelancerList.ToList();

                if (flist.Count == 0)
                    return NotFound("There's no freelancer available");

                return Ok(flist);
            }
            catch (Exception ex)
            {

                return BadRequest(ex.Message);
            }
        }

        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            try
            {
                var fId = _context.FreelancerList.Find(id);

                if (fId == null)
                    return NotFound($"There's no freelancer with id: {id}");

                return Ok(fId);
            }
            catch (Exception ex)
            {

                return BadRequest(ex.Message);
            }
        }

        [HttpPost]

        public IActionResult Post(Freelancer model)
        {
            try
            {
                _context.Add(model);
                _context.SaveChanges();
                return Ok("New freelancer added!");
            }
            catch (Exception ex)
            {

                return BadRequest(ex.Message);
            }
        }

        [HttpPut]

        public IActionResult Put(Freelancer model)
        {
            try
            {
                if (model == null )
                {
                    if (model == null)
                        return BadRequest("Invalid data");
                }

                var fDetails = _context.FreelancerList.Find(model.Id);
                if (fDetails == null)
                    return NotFound($"Freelancer with Id: {model.Id} is not exist");

                //fDetails.Username = model.Username;
                //fDetails.Email = model.Email;
                fDetails.PhoneNum = model.PhoneNum;
                fDetails.Skills = model.Skills;
                fDetails.Hobby = model.Hobby;
                _context.SaveChanges();
                return Ok("Freelancer details has been updated");
            }
            catch (Exception ex)
            {

                return BadRequest(ex.Message);
            }
   
        }

        [HttpDelete("{id}")]

        public IActionResult Delete(int id)
        {
            try
            {
                var fId = _context.FreelancerList.Find(id);

                if (fId == null)
                    return NotFound($"There's no freelancer with id: {id}");

                _context.Remove(fId);
                _context.SaveChanges();
                return Ok("The freelancer has been deleted");
            }
            catch (Exception ex)
            {

                return BadRequest(ex.Message);
            }
        }

    }
}
