﻿setTimeout(function () {
    $('.alert').alert('close');
}, 5000);