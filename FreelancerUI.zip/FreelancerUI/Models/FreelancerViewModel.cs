﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace FreelancerUI.Models
{
    public class FreelancerViewModel
    {
        public int Id { get; set; }
        [Required]
        [DisplayName("Username")]
        public string Username { get; set; }
        [Required]
        public string Email { get; set; }
        [Required]
        public string PhoneNum { get; set; }
        [Required]
        public string Skills { get; set; }
        public string Hobby { get; set; }
    }
}
