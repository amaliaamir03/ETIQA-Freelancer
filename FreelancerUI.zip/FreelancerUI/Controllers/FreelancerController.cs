﻿using FreelancerUI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding.Metadata;
using Newtonsoft.Json;
using System.Text;
using System.Text.Json.Serialization;

namespace FreelancerUI.Controllers
{
    public class FreelancerController : Controller
    {
        Uri APIAddress = new Uri("https://localhost:44366/api");
        private readonly HttpClient _httpClient;

        public FreelancerController()
        {
            _httpClient = new HttpClient();
            _httpClient.BaseAddress = APIAddress;
        }

        [HttpGet]
        public IActionResult Index()
        {
            List<FreelancerViewModel> list = new List<FreelancerViewModel>();
            HttpResponseMessage response = _httpClient.GetAsync(_httpClient.BaseAddress +
                "/freelancer/Get").Result;

            if(response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
                list = JsonConvert.DeserializeObject<List<FreelancerViewModel>>(data);
            }
            return View(list);
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]

        public IActionResult Create(FreelancerViewModel model)
        {
            try
            {
                string data = JsonConvert.SerializeObject(model);
                StringContent content = new StringContent(data, Encoding.UTF8, "application/json");
                HttpResponseMessage response = _httpClient.PostAsync(_httpClient.BaseAddress + "/freelancer/Post", content).Result;

                if (response.IsSuccessStatusCode)
                {
                    TempData["successMessage"] = "Freelancer Created";
                    return RedirectToAction("Index");
                }
            }
            catch (Exception ex)
            {
                TempData["errorMessage"] = ex.Message;
                return View();
            }
            
            return View();
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            try
            {
                FreelancerViewModel freelancer = new FreelancerViewModel();
                HttpResponseMessage response = _httpClient.GetAsync(APIAddress + "/freelancer/Get/" + id).Result;

                if (response.IsSuccessStatusCode)
                {
                    string data = response.Content.ReadAsStringAsync().Result;
                    freelancer = JsonConvert.DeserializeObject<FreelancerViewModel>(data);
                }
                return View(freelancer);
            }
            catch (Exception ex)
            {

                TempData["errorMessage"] = ex.Message;
                return View();
            }
            
        }

        [HttpPost]
        public IActionResult Edit(FreelancerViewModel model)
        {
            try
            {
                string data = JsonConvert.SerializeObject(model);
                StringContent content = new StringContent(data, Encoding.UTF8, "application/json");
                HttpResponseMessage response = _httpClient.PutAsync(APIAddress + "/freelancer/Put", content).Result;

                if (response.IsSuccessStatusCode)
                {
                    TempData["successMessage"] = "Freelancer details has been updated!";
                    return RedirectToAction("Index");
                }
            }
            catch (Exception ex)
            {

                TempData["errorMessage"] = ex.Message;
                return View();
            }
            return View();
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            try
            {
                FreelancerViewModel freelancer = new FreelancerViewModel();
                HttpResponseMessage response = _httpClient.GetAsync(APIAddress + "/freelancer/Get/" + id).Result;

                if (response.IsSuccessStatusCode)
                {
                    string data = response.Content.ReadAsStringAsync().Result;
                    freelancer = JsonConvert.DeserializeObject<FreelancerViewModel>(data);
                }
                return View(freelancer);
            }
            catch (Exception ex)
            {

                TempData["errorMessage"] = ex.Message;
                return View();
            }
            
        }

        [HttpPost, ActionName("Delete")]
        public IActionResult DeleteConfirmed(int id)
        {
            try
            {
                HttpResponseMessage response = _httpClient.DeleteAsync(APIAddress + "/freelancer/Delete/" + id).Result;

                if (response.IsSuccessStatusCode)
                {
                    TempData["successMessage"] = "Freelancer has been deleted.";
                    return RedirectToAction("Index");
                }
            }
            catch (Exception ex)
            {

                TempData["errorMessage"] = ex.Message;
                return View();
            }
            return View();
        }

    }
}
